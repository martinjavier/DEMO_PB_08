# demo_pb_08

Don't forget to install dependencies with: 
```
npm i
```
To run the project with node
```
npm start
```
To run the project with nodemon (you must have nodemon installed globally on your device)
```
npm run start-dev
```
# DEMO_PB_08
